export default class FriendAccount {
  label = ''
  addr = ''
  constructor (label, addr) {
    this.label = label
    this.addr = addr
  }
}
