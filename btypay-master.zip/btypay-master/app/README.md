# app

## Project setup
```
yarn install
如果出现报错，可能需要：npm install --global windows-build-tools(from https://github.com/felixrieseberg/windows-build-tools)
```

### Compiles and hot-reloads for development
```
yarn run serve
```

### Compiles and minifies for production
```
yarn run build
```

### Lints and fixes files
```
yarn run lint
```
